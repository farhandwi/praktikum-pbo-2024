import java.util.Scanner;

public class 105222048_Dhevan_PostTest2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        System.out.print("Masukkan nama mahasiswa: ");
        String nama = scanner.nextLine();

        System.out.print("Masukkan NIM mahasiswa: ");
        String nim = scanner.nextLine();

        System.out.print("Masukkan nilai tugas: ");
        double nilaiTugas = scanner.nextDouble();

        System.out.print("Masukkan nilai UTS: ");
        double nilaiUTS = scanner.nextDouble();

        System.out.print("Masukkan nilai UAS: ");
        double nilaiUAS = scanner.nextDouble();

        
        double rataRata = (nilaiTugas + nilaiUTS + nilaiUAS) / 3;

        
        System.out.println("\nData Mahasiswa:");
        System.out.println("NIM: " + nim);
        System.out.println("Nama: " + nama);
        System.out.println("Nilai Tugas: " + nilaiTugas);
        System.out.println("Nilai UTS: " + nilaiUTS);
        System.out.println("Nilai UAS: " + nilaiUAS);

       
        if (rataRata < 60) {
            System.out.println("Hasil: TIDAK LULUS");
        } else {
            System.out.println("Hasil: LULUS");

            
            for (int i = 0; i < 100; i++) {
                System.out.println(nama + " Akan mendapat nilai A pada praktikum PBO");
            }
        }

      
        System.out.print("\nBuat kelompok? (y/n): ");
        char createGroup = scanner.next().charAt(0);

        if (createGroup == 'y' || createGroup == 'Y') {
            System.out.print("Masukkan jumlah mahasiswa dalam kelompok (maksimal 3): ");
            int jumlahMahasiswa = scanner.nextInt();

            if (jumlahMahasiswa > 0 && jumlahMahasiswa <= 3) {
                System.out.print("Masukkan nama kelompok: ");
                String namaKelompok = scanner.next();

                System.out.println("\nKelompok " + namaKelompok + ":");
                for (int i = 0; i < jumlahMahasiswa; i++) {
                    System.out.print("Masukkan nama anggota ke-" + (i + 1) + ": ");
                    String anggotaKelompok = scanner.next();
                    System.out.println("Anggota " + (i + 1) + ": " + anggotaKelompok);
                }
            } else {
                System.out.println("Jumlah mahasiswa dalam kelompok harus antara 1-3.");
            }
        }

        scanner.close();
    }
}
