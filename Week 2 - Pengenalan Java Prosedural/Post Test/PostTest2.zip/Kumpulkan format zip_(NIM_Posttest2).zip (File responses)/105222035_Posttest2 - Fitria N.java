public class PosttestPBO1 {

    private static String nama = "Fitria Nurhaliza";
    private static String nim = "105222035";
    private static int nilaiTugas = 80;
    private static int nilaiUTS = 70;
    private static int nilaiUAS = 60;

    public static void main(String[] args) {

        System.out.println("Masukkan data mahasiswa:");
        System.out.println("Nama: " + nama);
        System.out.println("NIM: " + nim);
        System.out.println("Nilai Tugas: " + nilaiTugas);
        System.out.println("Nilai UTS: " + nilaiUTS);
        System.out.println("Nilai UAS: " + nilaiUAS);

        double rataRata = (nilaiTugas + nilaiUTS + nilaiUAS) / 3;

        System.out.println("\nHasil Kelulusan:");
        if (rataRata < 60) {
            System.out.println("TIDAK LULUS");
        } else {
            System.out.println("LULUS");
        }

        System.out.println("\nOtomasi Doa:");
        for (int i = 0; i < 1; i++) {
            System.out.println(nama + " akan mendapat nilai A pada praktikum PBO");
        }
    }
}
